# Colour → Transparent-on-White Solver

> Convert any solid colour into an equivalent RGBA-on-white, with live previews in light and dark mode.

A small React app that takes a solid colour and finds the equivalent RGBA (with transparency) that visually matches the same colour when composited on a white background.

## Features
- Input any solid hex colour.
- Adjust transparency with a slider (bounded by the minimum feasible alpha).
- See the computed foreground colour that, when blended with white, matches the original.
- Previews show both **target vs computed** side by side in **light and dark mode** contexts.
- Split-box previews: right half overlays a checkerboard background to demonstrate transparency.
- Copy-ready CSS output in both hex and rgba formats.

## Why?
Useful for design systems, UI theming, and situations where you need semi-transparent colours that look the same as a given solid on white backgrounds.

## Getting Started

### Prerequisites
- Node.js (>= 16)
- npm or yarn

### Installation
```bash
# Clone the repo
git clone https://github.com/yourusername/colour-on-white-solver.git
cd colour-on-white-solver

# Install dependencies
npm install
# or
yarn install
```

### Run the app
```bash
npm start
# or
yarn start
```
This starts the development server. Open [http://localhost:3000](http://localhost:3000) to view it in your browser.

## How it Works
The solver uses alpha compositing:
```
Target = α * Foreground + (1 − α) * White
Foreground = (Target − (1 − α) * White) / α
```

It also calculates the minimum feasible alpha to keep RGB values within [0–255]:
```
α_min = max(1 − R/255, 1 − G/255, 1 − B/255)
```

## Screenshots
- **Target (solid):** On white and on dark backgrounds.
- **Computed Foreground:** On white and on dark backgrounds, with half showing transparency.

## License
MIT
